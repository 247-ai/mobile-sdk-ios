//
//  _47ChatSDK.h
//  247ChatSDK
//
//  Created by Sourabh Shekhar Singh on 09/09/13.
//  Copyright (c) 2013 . All rights reserved.
//

#import <Foundation/Foundation.h>

#import <247ChatSDK/ChatSDK.h>

